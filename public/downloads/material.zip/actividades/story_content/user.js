function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6CTRGActw81":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

